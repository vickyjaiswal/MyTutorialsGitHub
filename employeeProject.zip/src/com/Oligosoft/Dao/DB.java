package com.Oligosoft.Dao;

import java.sql.PreparedStatement;

public interface DB {
	//PreparedStatement pstmt=null;
//	String className="com.mysql.jdbc.Driver";
//	String url="jdbc:mysql://localhost:3306/Oligosoft";
//	String userName="root";
//	String password="root";
	String className="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	String userName="Baba";
	String password="Baba";
	
	

}
