package com.Oligosoft.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DaoClass {
	static Connection con;
	
	public static Connection getConnection()
	{
		try
		{
			Class.forName(DB.className);
			con=DriverManager.getConnection(DB.url,DB.userName,DB.password);
			return con;
			
		}catch(ClassNotFoundException e)
		{
			e.printStackTrace();
			System.out.println("connection cant be created");
			return null;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			System.out.println("connection cant be created");
			return null;
		}
		//return con;
		
	}
	public void closeConnection()
	{
		try
		{
			con.close();
			
		}catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
	}

}
