package com.sathya;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import org.omg.SendingContext.RunTime;

import com.Oligosoft.Dao.DaoClass;

public class ActionListenerClass implements ActionListener,WindowListener {
	
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		if(jFrameClass.runTime==null){
			try {
				jFrameClass.runTime=Runtime.getRuntime().exec("C:/Windows/System32/osk.exe");
				SwingUtilities.updateComponentTreeUI(jFrameClass);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
	}


	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stu

	}


	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
		
		//jFrameClass.runTime=null;
		
		//jFrameClass.revalidate();
		//jFrameClass.repaint();
		try {
			
			
			Runtime.getRuntime().exec("C:/Windows/System32/osk.exe").destroy();
			Runtime.getRuntime().exit(0);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
			//SwingUtilities.updateComponentTreeUI(jFrameClass);
			//jFrameClass.repaint();
			
	}


	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	private static JFrameClass jFrameClass;

	private static DaoClass daoClass =new DaoClass();
	String eid,name,add,sal1,number1;
	double sal;
	long number;
	PreparedStatement pstmt=null;
	Statement stmt=null;
	ResultSet rs;
	Connection con;
	
	
	
	/*public static void setDaoClass(DaoClass daoClass) {
		ActionListenerClass.daoClass = daoClass;
	}*/


	public ActionListenerClass(JFrameClass jFrameClass){
		this.jFrameClass=jFrameClass;
	}


	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource()==jFrameClass.reset)
		{
			jFrameClass.empIdText.setText("");
			jFrameClass.eNameText.setText("");
			jFrameClass.salText.setText("");
			jFrameClass.addText.setText("");
			jFrameClass.phoText.setText("");
		}
		if(arg0.getSource()==jFrameClass.save)
		{
			String id=jFrameClass.empIdText.getText().trim();
			String ename=jFrameClass.eNameText.getText().trim();
			String salary=jFrameClass.salText.getText().trim();
			String address=jFrameClass.addText.getText().trim();
			String cell=jFrameClass.phoText.getText().trim();
			
			Double sal=0.0;
			long mob=0;
			
			if(id.isEmpty()){
				JOptionPane.showMessageDialog(jFrameClass, "Enter Employee ID!");
				
			}
			else if(id.charAt(0) != 'E'){
				JOptionPane.showMessageDialog(jFrameClass, "Employee ID must start with letter 'E'!");
			}
			else if(ename.isEmpty()){
				JOptionPane.showMessageDialog(jFrameClass, "Enter employee name!");
			}
			else if(salary.isEmpty()){
				JOptionPane.showMessageDialog(jFrameClass, "Enter Employee salary!");
			}
			if(salary.length()>0){
				try{
					
					sal=Double.parseDouble(salary);
				}catch(NumberFormatException nfe){
					JOptionPane.showMessageDialog(jFrameClass, "Enter valid salary!"+nfe.getMessage());
				}
			
				if((sal>0.0)){
				
					if(address.isEmpty()){
						JOptionPane.showMessageDialog(jFrameClass, "Enter Employee Address!");
					}
					else if(cell.isEmpty()){
						JOptionPane.showMessageDialog(jFrameClass, "Enter Employee mobile number!");
					}
					else if(cell.length() != 10){
						JOptionPane.showMessageDialog(jFrameClass, "Mobile number must be in 10 digits!");
					}
					
					
					if(cell.length()==10){
					
						try{
							mob=Long.parseLong(cell);
						}catch(NumberFormatException nfe){
							JOptionPane.showMessageDialog(jFrameClass, "Enter valid mobile number!"+nfe.getMessage());
						}
					}
					if(mob>0)
						
						
						try
						{
							
							con=daoClass.getConnection();
							 pstmt=con.prepareStatement("select * from employee where empid=?");
							 pstmt.setString(1, id);
							rs=pstmt.executeQuery();
							if(!rs.next())
						
							{
								con=daoClass.getConnection();
								pstmt=con.prepareStatement("insert into employee values(?,?,?,?,?)");
								pstmt.setString(1, id);
								pstmt.setString(2, ename);
								pstmt.setDouble(3, sal);
								pstmt.setString(4, address);
								pstmt.setLong(5, mob);
								int i=pstmt.executeUpdate();
								if(i==1)
								{
									JOptionPane.showMessageDialog(jFrameClass, "Record inserted successfully");
									sal=0.0;
									mob=0;
									
								}
								else
								{
									JOptionPane.showConfirmDialog(jFrameClass, "Erroe ! During storing the records into database");
									sal=0.0;
									mob=0;
								}
							}
							else
								
								
							{
							JOptionPane.showMessageDialog(jFrameClass, "This id is already exist !Choose anoterId");
							jFrameClass.empIdText.setText("");
							jFrameClass.eNameText.setText("");
							jFrameClass.salText.setText("");
							jFrameClass.addText.setText("");
							jFrameClass.phoText.setText("");
							
							sal=0.0;
							mob=0;
						    }
						
							
						
						}catch(Exception e)
						{
							e.printStackTrace();
						}
					}//else
					
					}
			}
		
			//else if(jFrameClass.phoText.getText()!=10)
//			
			
		
		if(arg0.getSource()==jFrameClass.vkdisable)
		{
			try {
				//jFrameClass.runTime=null;
				jFrameClass.runTime=Runtime.getRuntime().exec("C:/Windows/System32/osk.exe");
				//jFrameClass.revalidate();
				//jFrameClass.repaint();
				SwingUtilities.updateComponentTreeUI(jFrameClass);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(arg0.getSource()==jFrameClass.display)
		{
			String id=jFrameClass.empIdText.getText().trim();
			
				if(id.equals("")) 
				{
					JOptionPane.showMessageDialog(jFrameClass, "First Enter Employee Id to Fetch the record");
					
				}
				
				else
				{
					
					
						try
						{

							Connection con=daoClass.getConnection();
							pstmt=con.prepareStatement("select * from employee where empid=?");
							pstmt.setString(1, id);
							ResultSet rs=pstmt.executeQuery();
						PreparedStatement pstmt = con.prepareStatement("select * from employee where empid=?" );
						pstmt.setString(1, id);
						ResultSet rs1=pstmt.executeQuery();
						if(rs1.next())
						{
							 eid=rs1.getString(1);
							name=rs1.getString(2);
							sal=rs1.getDouble(3);
							 add = rs1.getString(4);
							number=rs1.getLong(5);
							number1=String.valueOf(number);
							sal1=String.valueOf(sal);
							
						
						jFrameClass.empIdText.setText(eid);
						jFrameClass.eNameText.setText(name);
						jFrameClass.salText.setText(sal1);
						jFrameClass.addText.setText(add);
						jFrameClass.phoText.setText(number1);
					}
						else{
							JOptionPane.showMessageDialog(jFrameClass, "Employee Id does not exist! Try Anoter one");
							jFrameClass.empIdText.setText("");
							jFrameClass.eNameText.setText("");
							jFrameClass.salText.setText("");
							jFrameClass.addText.setText("");
							jFrameClass.phoText.setText("");
						}	
					}
					
					
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}

	}


}
