package com.sathya;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.io.IOException;

import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class JFrameClass extends JFrame{
	JLabel empId,eName,sal,add,pho,heading;
	JTextField empIdText,eNameText,salText,addText,phoText;
	JButton save,display,reset, vKEnable, vkdisable;
	JButton enable,disable;
	JPanel pane1,pane2,pane3,pane4,pane5,pane6, pane7;
	public Object runTime=null;
	public JFrameClass()
	{
		/*try {
			runTime=Runtime.getRuntime().exec("C:/Windows/System32/osk.exe");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
//		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//	    int height = screenSize.height;
//	    int width = screenSize.width;
//	    setSize(width/2, height/2);
		//pack();
		setSize(1366, 768);
		//setLocationRelativeTo(null);
//		setResizable(false);
		
		setLayout(new GridBagLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setDefaultLookAndFeelDecorated(true);
		setTitle("Employee Details");
		//------------------------------------Lable-----------------------------------
		empId= new JLabel("Employee ID");
		eName =new JLabel("Ename");
		sal=new JLabel("Salary");
		add=new JLabel("Adress");
		pho= new JLabel("Mobile");
		heading=new JLabel("EMPLOYEE REGISTRATION FORM");
		heading.setFont(new Font("Courier New", Font.BOLD, 20));
		heading.setForeground(Color.blue);
		
		//-------------------------------------TextField------------------------------
		empIdText=new JTextField();
		eNameText=new JTextField();
		salText=new JTextField();
		addText=new JTextField();
		phoText=new JTextField();
		//------------------------------------JButton----------------------------------
		save=new JButton("SAVE");
		display=new JButton("DISPLAY");
		reset=new JButton("RESET");
		ImageIcon icon= new ImageIcon("./img/Keyboarda.png");

		vkdisable=new JButton(icon);
		//vKEnable=new JButton("Enable virtual keyboard");
		
		//--------------------------------------JPanel---------------------------------------
		
		pane1=new JPanel();
		GridLayout grid = new GridLayout(6,2,12,12);
		//pane1.setBounds(300, 300, 500, 500);
		pane1.setLayout(grid);
		pane1.add(empId);
		pane1.add(empIdText);
		pane1.add(eName);
		pane1.add(eNameText);
		pane1.add(sal);
		pane1.add(salText);
		pane1.add(add);
		pane1.add(addText);
		pane1.add(pho);
		pane1.add(phoText);
		
		
//		pane2=new JPanel();
//		pane3=new JPanel();
//		pane4=new JPanel();
//		pane5=new JPanel();
//		pane6=new JPanel();
//		pane1=new JPanel();
		//-------------------------------------Horizontal Box--------------------------

		Box hb1 = Box.createHorizontalBox();
		Box hb2 = Box.createHorizontalBox();
		Box hb3 = Box.createHorizontalBox();
//		Box hb4 = Box.createHorizontalBox();
//		Box hb5 = Box.createHorizontalBox();
//		Box hb6 = Box.createHorizontalBox();
		//---------------------------------------Vertical box---------------------------
		Box vb = Box.createVerticalBox();
		//-------------------------Adding the component in horizontal box---------------
		hb1.add(heading);
		//hb1.add(Box.createVerticalStrut(40));
		hb2.add(pane1);
		
		hb3.add(save);
		hb3.add(Box.createHorizontalStrut(30));
		hb3.add(reset);
		hb3.add(Box.createHorizontalStrut(30));
		hb3.add(display);
		hb3.add(Box.createHorizontalStrut(30));
		hb3.add(vkdisable);
		
		//----------------------------Adding the Horizontal box in vertical box--------------
		vb.add(hb1);
		vb.add(hb2);
		vb.add(hb3);
		//-----------------------------Adding the vertical box in JFarme----------------------
		
		add(vb);
										
		//-------------------------------Adding ActionEvent--------------------------------
		
		ActionListenerClass alc=new ActionListenerClass(this);
		save.addActionListener(alc);
		display.addActionListener(alc);
		reset.addActionListener(alc);
		vkdisable.addActionListener(alc);
		addWindowListener(alc);
		setVisible(true);
		//----------------------------VALIDATION------------------------------------
		
		
	}
	

}
